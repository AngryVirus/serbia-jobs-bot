"""Authenticated Telegram webhook and a scheduled collection endpoint."""
import asyncio
from collections import deque
from concurrent.futures import TimeoutError as FutureTimeout
import hmac
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import logging
import threading

LOG = logging.getLogger("serbia_jobs")
MAX_BODY = 256_000


class WebhookProcessor:
    def __init__(self, bot):
        self.bot = bot
        self.lock = asyncio.Lock()
        self.recent = deque(maxlen=1000)
        self.collection = None

    async def update(self, update):
        async with self.lock:
            update_id = update.get("update_id")
            if not isinstance(update_id, int):
                raise ValueError("Invalid update")
            if update_id in self.recent:
                return
            callback = update.get("callback_query", {})
            message = callback.get("message", {}) if callback else update.get("message", {})
            user = callback.get("from", {}) if callback else message.get("from", {})
            uid = user.get("id") if message.get("chat", {}).get("type") == "private" else None
            saved = self.bot.store.get_settings(uid).get("webhook_update_ids", []) if uid else []
            if update_id in saved:
                self.recent.append(update_id)
                return
            await self.bot.handle(update)
            self.recent.append(update_id)
            if uid and callback.get("data") != "delete_confirm":
                self.bot.store.update_settings(uid, webhook_update_ids=(saved + [update_id])[-100:])

    async def collect(self):
        if self.collection and not self.collection.done():
            return "already_running"

        async def run():
            await self.bot.scan()
            await self.bot.notify()

        self.collection = asyncio.create_task(run())
        # Retrieve errors so they do not expose request details in an asyncio traceback.
        def completed(task):
            if not task.cancelled() and task.exception():
                LOG.error("Scheduled collection failed (%s)", type(task.exception()).__name__)
        self.collection.add_done_callback(completed)
        return "started"


def make_handler(loop, processor, webhook_secret, collect_secret):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, format, *args):
            # Telegram bodies and credentials are never written to access logs.
            pass

        def respond(self, status, value):
            body = json.dumps(value).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError):
                pass

        def do_GET(self):
            if self.path == "/health":
                self.respond(200, {"ok": True})
            else:
                self.respond(404, {"error": "not_found"})

        def do_POST(self):
            if self.path == "/telegram":
                supplied = self.headers.get("X-Telegram-Bot-Api-Secret-Token", "")
                if not hmac.compare_digest(supplied, webhook_secret):
                    self.respond(403, {"error": "forbidden"})
                    return
                try:
                    length = int(self.headers.get("Content-Length", "0"))
                    if not 0 < length <= MAX_BODY:
                        raise ValueError
                    self.connection.settimeout(15)
                    value = json.loads(self.rfile.read(length))
                    if not isinstance(value, dict) or not isinstance(value.get("update_id"), int):
                        raise ValueError
                except (ValueError, OSError):
                    self.respond(400, {"error": "bad_request"})
                    return
                task = processor.update(value)
            elif self.path == "/collect":
                supplied = self.headers.get("X-Collect-Secret", "")
                if not hmac.compare_digest(supplied, collect_secret):
                    self.respond(403, {"error": "forbidden"})
                    return
                task = processor.collect()
            else:
                self.respond(404, {"error": "not_found"})
                return
            future = asyncio.run_coroutine_threadsafe(task, loop)
            try:
                result = future.result(timeout=90)
                self.respond(202 if self.path == "/collect" else 200, {"ok": True, "result": result})
            except FutureTimeout:
                # Do not cancel: a retry waits on the update lock and is deduplicated.
                self.respond(503, {"error": "retry_later"})
            except Exception as error:
                LOG.error("Webhook request failed (%s)", type(error).__name__)
                self.respond(503, {"error": "retry_later"})
    return Handler


async def serve(bot, base_url, webhook_secret, collect_secret, port):
    loop = asyncio.get_running_loop()
    processor = WebhookProcessor(bot)
    server = ThreadingHTTPServer(("0.0.0.0", port), make_handler(loop, processor, webhook_secret, collect_secret))
    server.daemon_threads = True
    worker = threading.Thread(target=server.serve_forever, daemon=True)
    worker.start()
    try:
        await bot.configure()
        await bot.api.call("setWebhook", url=base_url + "/telegram", secret_token=webhook_secret,
                           max_connections=1, allowed_updates=["message", "callback_query"])
        LOG.info("Webhook server is ready on port %d", port)
        await asyncio.Event().wait()
    finally:
        if processor.collection:
            processor.collection.cancel()
            await asyncio.gather(processor.collection, return_exceptions=True)
        await asyncio.to_thread(server.shutdown)
        server.server_close()
