"""Russian-language, multi-user Telegram job bot; Python 3.11+, no dependencies."""
import argparse
import asyncio
from datetime import datetime, timezone
from html import escape
import logging
import os
from pathlib import Path
import re
from zoneinfo import ZoneInfo

from filters import CITY_LABELS, matches, parse_datetime
from sources import SOURCES, collect_all
from store import Store
from telegram_api import TelegramAPI, TelegramError

LOG = logging.getLogger("serbia_jobs")
BELGRADE = ZoneInfo("Europe/Belgrade")
PAGE_SIZE = 5


def button(label, data):
    return {"text": label, "callback_data": data}


MENU = [[button("🔎 Найти вакансии", "search:0"), button("⚙️ Фильтры", "filters")],
        [button("🌐 Источники", "sources"), button("🔔 Уведомления", "notifications")],
        [button("⭐ Избранное", "favorites:0"), button("ℹ️ Помощь", "help")]]
BACK = [[button("← Главное меню", "menu")]]


def job_text(job):
    def e(value):
        return escape(str(value or "Не указано"))
    salary = "Не указана"
    if job.get("salary_min") is not None:
        salary = f"от {job['salary_min']:g} {job.get('salary_currency') or ''} / месяц"
    remote = {True: "Да", False: "Нет", None: "Не указано"}[job.get("remote")]
    russian = {True: "Упоминается", False: "Не указан", None: "Не указано"}[job.get("russian")]
    serbian = {True: "Требуется", False: "Явно не требуется", None: "Не указано"}[job.get("serbian_required")]
    description = (job.get("description") or "Описание доступно по ссылке.")[:850]
    source = SOURCES[job["source"]].name
    return (f"<b>{e(job['title'])}</b>\n{e(job.get('company'))}\n"
            f"📍 {e(job.get('location'))}\n💶 {e(salary)}\n"
            f"🏠 Удалённо: {remote}\n🗣 Русский: {russian} · Сербский: {serbian}\n\n"
            f"{e(description)}\n\nИсточник: {e(source)}\n"
            f"<a href=\"{escape(job['url'], quote=True)}\">Открыть вакансию</a>")


def daily_due(user, now):
    settings = user["settings"]
    local = now.astimezone(BELGRADE)
    last = parse_datetime(user.get("last_notified_at"))
    return (local.hour >= settings["daily_hour"] and
            (last is None or last.astimezone(BELGRADE).date() < local.date()))


class Bot:
    def __init__(self, api, store, scan_minutes=30):
        self.api, self.store = api, store
        self.scan_minutes = scan_minutes
        self.pending = {}
        self.scanning = False

    def set_pending(self, uid, field):
        self.pending[uid] = field
        self.store.update_settings(uid, pending_input=field)

    def clear_pending(self, uid):
        self.pending.pop(uid, None)
        if self.store.get_settings(uid).get("pending_input") is not None:
            self.store.update_settings(uid, pending_input=None)

    async def panel(self, chat_id, text, rows, message_id=None):
        if message_id:
            try:
                await self.api.call("editMessageText", chat_id=chat_id, message_id=message_id,
                                    text=text, parse_mode="HTML", reply_markup={"inline_keyboard": rows})
                return
            except TelegramError as error:
                if "message is not modified" in str(error):
                    return
                if error.code != 400:
                    raise
        await self.api.send(chat_id, text, rows)

    async def filters(self, uid, chat, mid=None):
        s = self.store.get_settings(uid)
        keywords = escape(", ".join(s["keywords"]) or "Любые")
        excluded = escape(", ".join(s["exclusions"]) or "Нет")
        remote = {"any": "Любой", "only": "Удалённо", "office": "В офисе"}[s["remote"]]
        language = {"any": "Любые", "russian": "С упоминанием русского", "no_serbian": "Без обязательного сербского"}[s["language"]]
        salary = "Любая" if s["min_salary"] is None else f"от {s['min_salary']:g} {s['currency']} / месяц"
        text = (f"<b>Ваши фильтры</b>\n\nСлова: {keywords}\nИсключить: {excluded}\n"
                f"Город: {CITY_LABELS[s['city']]}\nФормат: {remote}\nЯзыки: {language}\n"
                f"Зарплата: {salary}\nБез зарплаты: {'показывать' if s['include_unknown_salary'] else 'скрывать'}\n\n"
                "Слова работают как «ИЛИ», остальные фильтры — вместе. "
                "Поиск по словам идёт на языке объявления; перевод пока не подключён. "
                "Если языковые требования или формат работы не указаны, строгий фильтр такую вакансию скроет.")
        rows = [[button("Ключевые слова", "input:keywords"), button("Исключить слова", "input:exclusions")],
                [button("Город", "city"), button("Формат работы", "remote")],
                [button("Языки", "language"), button("Минимальная зарплата", "input:salary")],
                [button("Вакансии без зарплаты: " + ("✓" if s["include_unknown_salary"] else "✕"), "toggle_salary")],
                [button("Сбросить фильтры", "reset")]] + BACK
        await self.panel(chat, text, rows, mid)

    async def sources(self, uid, chat, mid=None):
        selected = self.store.get_settings(uid)["sources"]
        statuses = self.store.source_status()
        lines = ["<b>Ваши источники</b>", "Нажмите, чтобы включить или выключить источник.",
                 "Подключения экспериментальные: работоспособность зависит от сайта.\n"]
        labels = {"ok": "собран", "partial": "собран частично", "empty": "вакансии не извлечены", "blocked": "доступ ограничен",
                  "robots_disallowed": "сбор запрещён robots.txt", "robots_unavailable": "robots.txt не проверен",
                  "error": "ошибка", "unsupported": "нужна доработка",
                  "requires_permission": "нужно разрешение владельца сайта"}
        rows = []
        for key, source in SOURCES.items():
            status = statuses.get(key, {})
            state = status.get("state", "unchecked")
            label = labels.get(state, "не проверен")
            lines.append(f"• {escape(source.name)} — {label}, {status.get('count', 0)} вакансий")
            if status.get("checked_at"):
                lines.append(f"  Проверка: {escape(str(status['checked_at'])[:16])} UTC")
            rows.append([button(("✓ " if key in selected else "○ ") + source.name, "source:" + key)])
        await self.panel(chat, "\n".join(lines), rows + BACK, mid)

    async def notifications(self, uid, chat, mid=None):
        s = self.store.get_settings(uid)
        current = {"off": "Выключены", "instant": "После каждой проверки источников", "daily": "Ежедневная подборка"}[s["notifications"]]
        await self.panel(chat, f"<b>Уведомления</b>\n\nСейчас: {current}\n"
                         f"Проверка источников: примерно каждые {self.scan_minutes} минут.\n"
                         f"Подборка: {s['daily_hour']:02}:00 по времени Белграда.\n"
                         "За один проход отправляется до 10 вакансий. Остальные доступны через поиск. "
                         "Уже отправленные вакансии не повторяются.",
                         [[button("Выключить", "notify:off")], [button("При проверке", "notify:instant")],
                          [button("Раз в день", "notify:daily"), button("Час подборки", "input:hour")]] + BACK, mid)

    async def results(self, uid, chat, page=0, favorites=False):
        settings = self.store.get_settings(uid)
        jobs = self.store.favorites(uid) if favorites else [j for j in self.store.list_jobs() if matches(j, settings)]
        page = min(max(page, 0), max((len(jobs) - 1) // PAGE_SIZE, 0))
        if not jobs:
            text = "Избранное пока пусто." if favorites else (
                "Подходящих вакансий пока нет. Попробуйте расширить фильтры и проверьте статусы источников. "
                "При первом запуске сбор может занять несколько минут.")
            await self.api.send(chat, text, BACK)
            return
        saved = {j["id"] for j in self.store.favorites(uid)}
        await self.api.send(chat, f"{'Избранное' if favorites else 'Найдено'}: {len(jobs)}. Страница {page + 1}.")
        for job in jobs[page * PAGE_SIZE:(page + 1) * PAGE_SIZE]:
            is_saved = job["id"] in saved
            await self.api.send(chat, job_text(job), [[button("Убрать из избранного" if is_saved else "⭐ Сохранить",
                                                            f"favorite:{job['id']}:{0 if is_saved else 1}")]])
        prefix = "favorites" if favorites else "search"
        pages = []
        if page:
            pages.append(button("← Назад", f"{prefix}:{page - 1}"))
        if (page + 1) * PAGE_SIZE < len(jobs):
            pages.append(button("Далее →", f"{prefix}:{page + 1}"))
        await self.api.send(chat, "Фильтры и данные источников доступны в меню.", ([pages] if pages else []) + BACK)

    async def help(self, chat, mid=None):
        await self.panel(chat, "<b>Работа в Сербии</b>\n\n"
                         "Выберите источники и фильтры, затем нажмите «Найти вакансии». "
                         "У каждого пользователя свои настройки и избранное. Уведомления включаются отдельно.\n\n"
                         "Ключевые слова вводятся через запятую, например: developer, программист, kuvar. "
                         "Отсутствие упоминания сербского не означает, что он не нужен. "
                         "Языковые пометки основаны на тексте, условия следует проверить у работодателя.\n\n"
                         "Бот показывает публичные объявления и ссылки на оригиналы. "
                         "На части сайтов сбор может не работать. Даты и зарплаты могут отсутствовать. "
                         "Валюты не пересчитываются, зарплата сравнивается только за месяц.\n\n"
                         "/menu — меню · /cancel — отмена ввода\n"
                         "/delete_me — удалить настройки, избранное и историю уведомлений.", BACK, mid)

    async def input_value(self, uid, chat, text):
        field = self.pending[uid]
        try:
            if field in ("keywords", "exclusions"):
                values = [] if text.strip() == "-" else list(dict.fromkeys(x.strip() for x in text.split(",") if x.strip()))
                if len(values) > 15 or any(len(x) > 60 for x in values):
                    raise ValueError("Максимум 15 слов или фраз, до 60 символов каждое.")
                self.store.update_settings(uid, **{field: values})
            elif field == "salary":
                if text.strip() == "-":
                    self.store.update_settings(uid, min_salary=None)
                else:
                    match = re.fullmatch(r"\s*(\d+(?:[.,]\d{1,2})?)\s+(EUR|RSD)\s*", text.upper())
                    if not match or float(match[1].replace(",", ".")) > 100_000_000:
                        raise ValueError("Введите сумму в месяц и валюту: 1000 EUR или 120000 RSD. «-» — снять фильтр.")
                    self.store.update_settings(uid, min_salary=float(match[1].replace(",", ".")), currency=match[2])
            elif field == "hour":
                if not text.strip().isdigit() or not 0 <= int(text.strip()) <= 23:
                    raise ValueError("Введите час от 0 до 23 по времени Белграда.")
                self.store.update_settings(uid, daily_hour=int(text.strip()))
            else:
                raise ValueError("Неизвестная настройка. Используйте /cancel.")
        except ValueError as error:
            await self.api.send(chat, escape(str(error)))
            return
        self.clear_pending(uid)
        if field == "hour":
            await self.notifications(uid, chat)
        else:
            await self.filters(uid, chat)

    async def handle(self, update):
        callback = update.get("callback_query")
        message = callback.get("message", {}) if callback else update.get("message", {})
        user = callback.get("from", {}) if callback else message.get("from", {})
        chat = message.get("chat", {})
        if chat.get("type") != "private" or not user.get("id") or user.get("is_bot"):
            if callback:
                await self.api.call("answerCallbackQuery", callback_query_id=callback["id"], text="Откройте личный чат с ботом.")
            return
        uid, chat_id = user["id"], chat["id"]
        self.store.ensure_user(uid, chat_id)
        if callback:
            await self.api.call("answerCallbackQuery", callback_query_id=callback["id"])
            action = callback.get("data", "")
            mid = message.get("message_id")
            self.clear_pending(uid)
        else:
            text = message.get("text", "")
            if not text:
                return
            if len(text) > 1000:
                await self.api.send(chat_id, "Пожалуйста, сократите сообщение до 1000 символов.")
                return
            saved_pending = self.store.get_settings(uid).get("pending_input")
            if saved_pending and uid not in self.pending:
                self.pending[uid] = saved_pending
            if uid in self.pending and not text.startswith("/"):
                await self.input_value(uid, chat_id, text)
                return
            self.clear_pending(uid)
            command = text.split()[0].split("@")[0]
            action = {"/start": "menu", "/menu": "menu", "/cancel": "menu", "/help": "help",
                      "/filters": "filters", "/settings": "filters", "/sources": "sources", "/search": "search:0",
                      "/favorites": "favorites:0", "/delete_me": "delete"}.get(command, "menu")
            mid = None
        if action == "menu":
            await self.panel(chat_id, "<b>Работа в Сербии 🇷🇸</b>\nПоиск вакансий с вашими личными настройками.\n"
                             "Уведомления по умолчанию выключены. С чего начнём?", MENU, mid)
        elif action == "help":
            await self.help(chat_id, mid)
        elif action == "filters":
            await self.filters(uid, chat_id, mid)
        elif action == "sources":
            await self.sources(uid, chat_id, mid)
        elif action.startswith("source:") and action[7:] in SOURCES:
            key = action[7:]
            selected = self.store.get_settings(uid)["sources"]
            selected = [x for x in selected if x != key] if key in selected else selected + [key]
            self.store.update_settings(uid, sources=selected)
            await self.sources(uid, chat_id, mid)
        elif action.startswith(("search:", "favorites:")):
            try:
                page = int(action.split(":")[1])
            except ValueError:
                return
            await self.results(uid, chat_id, page, action.startswith("favorites:"))
        elif action.startswith("favorite:"):
            parts = action.split(":")
            if len(parts) != 3 or not parts[1].isdigit() or parts[2] not in ("0", "1"):
                return
            job_id, enabled = int(parts[1]), parts[2] == "1"
            job = self.store.get_job(job_id)
            if job:
                self.store.set_favorite(uid, job_id, enabled)
                await self.panel(chat_id, job_text(job), [[button("Убрать из избранного" if enabled else "⭐ Сохранить",
                                                            f"favorite:{job_id}:{0 if enabled else 1}")]], mid)
        elif action == "notifications":
            await self.notifications(uid, chat_id, mid)
        elif action.startswith("notify:") and action[7:] in ("off", "instant", "daily"):
            self.store.update_settings(uid, notifications=action[7:])
            await self.notifications(uid, chat_id, mid)
        elif action.startswith("input:") and action[6:] in ("keywords", "exclusions", "salary", "hour"):
            field = action[6:]
            self.set_pending(uid, field)
            prompt = {"keywords": "Введите слова или фразы через запятую. Достаточно совпадения одного. «-» — очистить.",
                      "exclusions": "Введите слова, по которым нужно исключать вакансии, через запятую. «-» — очистить.",
                      "salary": "Введите минимальную зарплату в месяц: 1000 EUR или 120000 RSD. «-» — снять фильтр.",
                      "hour": "Введите час ежедневной подборки от 0 до 23, время Белграда."}[field]
            await self.panel(chat_id, prompt + "\n/cancel — отмена.", BACK, mid)
        elif action in ("city", "remote", "language"):
            values = {"city": CITY_LABELS,
                      "remote": {"any": "Любой", "only": "Только удалённо", "office": "Только офис"},
                      "language": {"any": "Любые требования", "russian": "Упоминается русский язык",
                                   "no_serbian": "Явно не требуется сербский"}}[action]
            await self.panel(chat_id, "Выберите значение фильтра.",
                             [[button(label, f"set:{action}:{value}")] for value, label in values.items()] + BACK, mid)
        elif action.startswith("set:"):
            parts = action.split(":")
            allowed = {"city": CITY_LABELS, "remote": ("any", "only", "office"),
                       "language": ("any", "russian", "no_serbian")}
            if len(parts) == 3 and parts[1] in allowed and parts[2] in allowed[parts[1]]:
                self.store.update_settings(uid, **{parts[1]: parts[2]})
                await self.filters(uid, chat_id, mid)
        elif action == "toggle_salary":
            self.store.update_settings(uid, include_unknown_salary=not self.store.get_settings(uid)["include_unknown_salary"])
            await self.filters(uid, chat_id, mid)
        elif action == "reset":
            self.store.update_settings(uid, keywords=[], exclusions=[], city="any", remote="any", language="any",
                                       min_salary=None, currency="EUR", include_unknown_salary=True)
            await self.filters(uid, chat_id, mid)
        elif action == "delete":
            await self.panel(chat_id, "Удалить ваши настройки, избранное и историю уведомлений?",
                             [[button("Удалить мои данные", "delete_confirm")]] + BACK, mid)
        elif action == "delete_confirm":
            self.store.delete_user(uid)
            await self.api.send(chat_id, "Ваши данные удалены. Уведомления выключены. /start — начать заново.")

    async def scan(self):
        if self.scanning:
            return
        self.scanning = True
        try:
            jobs, statuses = await asyncio.to_thread(collect_all)
            added = self.store.save_jobs(jobs)
            self.store.set_source_status(statuses)
            LOG.info("Collection: %d records, %d new; %d sources", len(jobs), added, len(statuses))
        except Exception as error:
            LOG.error("Collection failed (%s)", type(error).__name__)
        finally:
            self.scanning = False

    async def notify(self, now=None):
        now = now or datetime.now(timezone.utc)
        users = [u for u in self.store.subscribers() if u["settings"]["notifications"] != "off" and
                 (u["settings"]["notifications"] != "daily" or daily_due(u, now))]
        if not users:
            return
        jobs = self.store.list_jobs()
        for user in users:
            uid, settings = user["user_id"], user["settings"]
            delivered = self.store.delivered_job_ids(uid)
            pending = [j for j in jobs if matches(j, settings, now) and j["id"] not in delivered]
            try:
                for job in pending[:10]:
                    await self.api.send(user["chat_id"], job_text(job),
                                        [[button("⭐ Сохранить", f"favorite:{job['id']}:1")]])
                    self.store.mark_delivered(uid, job["id"])
                    await asyncio.sleep(0.1)
                self.store.mark_notified(uid, now.isoformat())
            except TelegramError as error:
                if error.code == 403:
                    self.store.update_settings(uid, notifications="off")
                LOG.warning("Notification delivery failed (%s)", error.code)

    async def scheduler(self):
        next_scan = 0
        loop = asyncio.get_running_loop()
        while True:
            if loop.time() >= next_scan:
                await self.scan()
                next_scan = loop.time() + self.scan_minutes * 60
            try:
                await self.notify()
            except Exception as error:
                LOG.error("Notification cycle failed (%s)", type(error).__name__)
            await asyncio.sleep(60)

    async def configure(self):
        me = await self.api.call("getMe")
        LOG.info("Telegram bot connected: @%s", me.get("username", "unknown"))
        await self.api.call("setMyCommands", commands=[
            {"command": "menu", "description": "Главное меню"},
            {"command": "search", "description": "Найти вакансии"},
            {"command": "filters", "description": "Фильтры поиска"},
            {"command": "sources", "description": "Источники и их статус"},
            {"command": "favorites", "description": "Избранное"},
            {"command": "delete_me", "description": "Удалить мои данные"}])

    async def run(self):
        await self.configure()
        scheduler = asyncio.create_task(self.scheduler())
        offset = 0
        try:
            while True:
                try:
                    updates = await self.api.call("getUpdates", offset=offset, timeout=45,
                                                  allowed_updates=["message", "callback_query"])
                    for update in updates:
                        try:
                            await self.handle(update)
                        except Exception as error:
                            LOG.error("Update failed (%s)", type(error).__name__)
                        offset = update["update_id"] + 1
                except TelegramError as error:
                    if error.code in (401, 409):
                        raise
                    LOG.warning("Telegram polling unavailable (%s); retrying", error.code)
                    await asyncio.sleep(5)
        finally:
            scheduler.cancel()
            await asyncio.gather(scheduler, return_exceptions=True)


def load_env(path):
    """Only task-specific variables; no shell evaluation or expansion."""
    if not path.exists():
        return
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        if key in ("TELEGRAM_BOT_TOKEN", "DATABASE_PATH", "SCAN_INTERVAL_MINUTES", "SUPABASE_URL",
                   "SUPABASE_SERVICE_ROLE_KEY", "WEBHOOK_BASE_URL", "WEBHOOK_SECRET", "COLLECT_SECRET", "PORT"):
            os.environ.setdefault(key, value.strip().strip("\"'"))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--collect", action="store_true", help="Collect once without a Telegram token")
    parser.add_argument("--status", action="store_true", help="Print stored source statuses")
    parser.add_argument("--webhook", action="store_true", help="Web server for free cloud hosting")
    args = parser.parse_args()
    load_env(Path(__file__).with_name(".env"))
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    if os.environ.get("SUPABASE_URL") and os.environ.get("SUPABASE_SERVICE_ROLE_KEY"):
        from cloud_store import SupabaseStore
        store = SupabaseStore(os.environ["SUPABASE_URL"], os.environ["SUPABASE_SERVICE_ROLE_KEY"])
    else:
        if args.webhook:
            parser.error("Webhook mode requires SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY for persistent storage.")
        store = Store(os.environ.get("DATABASE_PATH", str(Path(__file__).parent / "data" / "jobs.sqlite3")))
    if args.status:
        for key, status in store.source_status().items():
            print(key, status.get("state"), status.get("count", 0), status.get("detail", ""))
        return
    if args.collect:
        jobs, statuses = collect_all()
        print("New vacancies:", store.save_jobs(jobs))
        store.set_source_status(statuses)
        for key, status in statuses.items():
            print(key, status.get("state"), status.get("count", 0), status.get("detail", ""))
        return
    token = os.environ.get("TELEGRAM_BOT_TOKEN", "")
    if not re.fullmatch(r"\d+:[A-Za-z0-9_-]{20,}", token):
        parser.error("Set TELEGRAM_BOT_TOKEN in .env (see .env.example).")
    try:
        minutes = int(os.environ.get("SCAN_INTERVAL_MINUTES", "30"))
        if minutes < 15:
            raise ValueError
    except ValueError:
        parser.error("SCAN_INTERVAL_MINUTES must be an integer >= 15.")
    try:
        bot = Bot(TelegramAPI(token), store, minutes)
        if args.webhook:
            from web_server import serve
            base_url = os.environ.get("WEBHOOK_BASE_URL") or os.environ.get("RENDER_EXTERNAL_URL", "")
            webhook_secret = os.environ.get("WEBHOOK_SECRET", "")
            collect_secret = os.environ.get("COLLECT_SECRET", "")
            if not base_url.startswith("https://") or any(c in base_url for c in "?#"):
                parser.error("Set WEBHOOK_BASE_URL to the public HTTPS service URL.")
            if not re.fullmatch(r"[A-Za-z0-9_-]{32,256}", webhook_secret) or len(collect_secret) < 32:
                parser.error("Set WEBHOOK_SECRET and COLLECT_SECRET to random strings of at least 32 characters.")
            asyncio.run(serve(bot, base_url.rstrip("/"), webhook_secret, collect_secret,
                              int(os.environ.get("PORT", "10000"))))
        else:
            asyncio.run(bot.run())
    except KeyboardInterrupt:
        pass
    except TelegramError as error:
        LOG.error("Telegram error: %s", str(error))
        raise SystemExit(1) from None


if __name__ == "__main__":
    main()
