"""Small Telegram Bot API client. Does not log URLs containing the token."""
import asyncio
import json
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


class TelegramError(Exception):
    def __init__(self, description, code=0, retry_after=None):
        super().__init__(description)
        self.code = code
        self.retry_after = retry_after


class TelegramAPI:
    def __init__(self, token):
        self._token = token
        self._base = "https://api.telegram.org/bot" + token + "/"

    def _request(self, method, params):
        request = Request(self._base + method, data=json.dumps(params).encode(),
                          headers={"Content-Type": "application/json"}, method="POST")
        try:
            with urlopen(request, timeout=65) as response:
                result = json.load(response)
        except HTTPError as error:
            try:
                result = json.loads(error.read())
            except (ValueError, OSError):
                raise TelegramError("Telegram HTTP error", error.code) from None
        except (URLError, TimeoutError, OSError):
            raise TelegramError("Нет соединения с Telegram") from None
        if not result.get("ok"):
            raise TelegramError(str(result.get("description", "Telegram error")).replace(self._token, "[token]"),
                                result.get("error_code", 0),
                                result.get("parameters", {}).get("retry_after"))
        return result["result"]

    async def call(self, method, **params):
        for attempt in range(3):
            try:
                return await asyncio.to_thread(self._request, method, params)
            except TelegramError as error:
                if error.code != 429 or attempt == 2:
                    raise
                await asyncio.sleep(min(error.retry_after or 2, 60))

    async def send(self, chat_id, text, rows=None):
        params = {"chat_id": chat_id, "text": text, "parse_mode": "HTML",
                  "link_preview_options": {"is_disabled": True}}
        if rows is not None:
            params["reply_markup"] = {"inline_keyboard": rows}
        return await self.call("sendMessage", **params)
