"""Job matching shared by manual search and notifications."""
from datetime import datetime, timedelta, timezone
import re
import unicodedata

CITY_NAMES = {
    "belgrade": ("beograd", "belgrade", "белград", "београд"),
    "novi_sad": ("novi sad", "нови сад", "нови-сад"),
    "nis": ("nis", "ниш", "ниш"),
    "subotica": ("subotica", "суботица"),
    "kragujevac": ("kragujevac", "крагуевац", "крагујевац"),
}
CITY_LABELS = {"any": "Вся Сербия", "belgrade": "Белград", "novi_sad": "Нови-Сад",
               "nis": "Ниш", "subotica": "Суботица", "kragujevac": "Крагуевац"}


def normalize(text):
    text = unicodedata.normalize("NFKD", text.casefold().replace("đ", "dj"))
    return " ".join("".join(c for c in text if not unicodedata.combining(c)).split())


def contains(text, term):
    """Whole words/phrases: 'nis' must not match 'business'."""
    return bool(re.search(r"(?<!\w)" + re.escape(normalize(term)) + r"(?!\w)", text))


def parse_datetime(value):
    if not value:
        return None
    try:
        result = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return result.replace(tzinfo=timezone.utc) if result.tzinfo is None else result
    except (ValueError, TypeError):
        return None


def active(job, now=None):
    now = now or datetime.now(timezone.utc)
    expiry = parse_datetime(job.get("expires_at"))
    if expiry and expiry <= now:
        return False
    # Unknown publication dates are retained for 30 days from first discovery.
    published = parse_datetime(job.get("published_at")) or parse_datetime(job.get("created_at"))
    return not published or published >= now - timedelta(days=30)


def matches(job, settings, now=None):
    if not active(job, now) or job["source"] not in settings["sources"]:
        return False
    text = normalize(" ".join(str(job.get(k) or "") for k in ("title", "company", "description")))
    if settings["keywords"] and not any(contains(text, x) for x in settings["keywords"]):
        return False
    if any(contains(text, x) for x in settings["exclusions"]):
        return False
    city = settings["city"]
    if city != "any":
        location = normalize(job.get("location") or "")
        if not any(contains(location, x) for x in CITY_NAMES.get(city, (city,))):
            return False
    if settings["remote"] == "only" and job.get("remote") is not True:
        return False
    if settings["remote"] == "office" and job.get("remote") is not False:
        return False
    if settings["language"] == "russian" and job.get("russian") is not True:
        return False
    if settings["language"] == "no_serbian" and job.get("serbian_required") is not False:
        return False
    minimum = settings.get("min_salary")
    if minimum is not None:
        salary = job.get("salary_min")
        currency = job.get("salary_currency")
        if salary is None or currency is None:
            return bool(settings["include_unknown_salary"])
        if currency != settings["currency"] or salary < minimum:
            return False
    return True
